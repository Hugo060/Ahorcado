package Ahorcado;

import java.io.*;
import java.util.Scanner;

public class Funciones {
    
// Lee el archivo del Quijote leyendo letra por letra guardandolo en un array 
    public static char[] leerArchivoLetraPorLetra(String rutaArchivo) {
        File archivo = new File(rutaArchivo);
        StringBuilder contenido = new StringBuilder();
        int letra;

        //Comprueba si el archivo existe y puede ser leido.
        if (archivo.exists() && archivo.canRead()) {
            try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) {
                while ((letra = lector.read()) != -1) {
                    contenido.append((char) letra);
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
        }

        return contenido.toString().toCharArray();
    }

    // Filtra las palabras del texto
    public static String[] obtenerPalabras(String texto, String[] stopWords, int minimoLetras) {
        String[] palabras = texto.split("\\W+"); // Filtra las palabras hasta encontrar carácteres no alfanuméricos
        int validas = 0;

        for (String palabra : palabras) {
            if (esPalabraValida(palabra, stopWords, minimoLetras)) {
                validas++;
            }
        }

        String[] palabrasFiltradas = new String[validas];
        int index = 0;

        for (String palabra : palabras) {
            if (esPalabraValida(palabra, stopWords, minimoLetras)) {
                palabrasFiltradas[index++] = palabra;
            }
        }

        return palabrasFiltradas;
    }

    // Comprueba que la palabra no sea una StopWord
    public static boolean esPalabraValida(String palabra, String[] stopWords, int minimoLetras) {
        if (palabra.length() < minimoLetras) {
            return false;
        }
        for (String stopWord : stopWords) {
            if (palabra.equalsIgnoreCase(stopWord)) {
                return false;
            }
        }
        return true;
    }

    // Selecciona una palabra 
    public static String seleccionarPalabra(String textoCompleto, String[] stopWords, int minimoLetras) {
        String[] palabras = obtenerPalabras(textoCompleto, stopWords, minimoLetras);
        if (palabras.length == 0) {
            return null;
        }
        return palabras[(int) (Math.random() * palabras.length)];
    }

    // Inicia el juego
    public static void iniciarJuego(String rutaArchivo) {
        char[] caracteres = leerArchivoLetraPorLetra(rutaArchivo);
        String textoCompleto = new String(caracteres);
        String[] stopWords = obtenerStopWords();
        String palabra = seleccionarPalabra(textoCompleto, stopWords, 5);
        jugar(palabra);
    }

    /*
     Comprueba si ha llegado al maximo de errores.
     En caso que no llegue, incrementa los errores si falla.
     Si acierta la letra la añade al progreso.
     Si se quiere rendir, le dice que pulse -1 y si lo hace, se termina el juego
     */
    public static void jugar(String palabra) {
        char[] progreso = inicializarProgreso(palabra);
        char[] letrasIntentadas = new char[26]; //por 26 letras de abecedario
        int contadorLetras = 0;
        int errores = 0;
        int maxErrores = 6; //todos los errores posibles

        Scanner scanner = new Scanner(System.in);

        while (errores < maxErrores) {
            mostrarHorca(errores);
            mostrarProgreso(progreso);

            // Cuando tenga 3 errores le da una ayuda aleatoria entre 3 opciones.   
            if (errores == 3) {
                ayuda(progreso, palabra, letrasIntentadas);
            }

            System.out.print("Introduce una letra: ");
            String entrada = scanner.nextLine().toLowerCase();

            // Comprueba si el jugador se ha rendido
            if (entrada.equals("-1")) {
                System.out.println("Te has rendido. La palabra era: " + palabra);
                break;
            }

            // Comprueba si la letra es válida
            if (entrada.length() != 1 || !Character.isLetter(entrada.charAt(0))) {
                System.out.println("Entrada inválida. Introduce una sola letra.");
                continue;
            }
            char letra = entrada.charAt(0);

            // Comprueba si la letra ya ha sido intentada
            if (yaIntentada(letra, letrasIntentadas)) {
                System.out.println("Ya has intentado la letra '" + letra + "'. Prueba con otra.");
                continue;
            }
            letrasIntentadas[contadorLetras++] = letra;

            // Si la letra que introduce está, se añade al progreso
            if (letraEnPalabra(palabra, letra)) {
                System.out.println("Correcto. La letra '" + letra + "' está en la palabra.");
                actualizarProgreso(palabra, progreso, letra);

                if (palabraCompleta(progreso)) {
                    System.out.println("¡Felicidades! Has adivinado la palabra: " + palabra);
                    break;
                }
            } else {
                // Si la letra que introduce no está, suma un error
                System.out.println("Incorrecto. La letra '" + letra + "' no está en la palabra.");
                errores++;
            }
        }

        // Si el número máximo de errores se alcanza, dice que ya ha perdido
        if (errores == maxErrores) {
            mostrarHorca(errores);  // Muestra la horca completa
            System.out.println("Has perdido, la palabra era: " + palabra);
        }
    }

    public static void ayuda(char[] progreso, String palabra, char[] letrasIntentadas) {
    int ayuda = (int) (Math.random() * 3) + 1;

    switch (ayuda) {
        case 1: // Eliminar un fallo de la horca
            System.out.println("¡Ayuda! Un fallo ha sido eliminado.");
            break;
        case 2: // Revela una vocal no descubierta
            System.out.println("¡Ayuda! Una vocal extra ha sido revelada.");
            for (int i = 0; i < palabra.length(); i++) {
                if ("aeiou".indexOf(palabra.charAt(i)) >= 0 && progreso[i] == '_') {
                    progreso[i] = palabra.charAt(i);
                    break;
                }
            }
            break;
        case 3: // Revela una consonante no descubierta
            System.out.println("¡Ayuda! Una consonante extra ha sido revelada.");           
            for (int i = 0; i < palabra.length(); i++) {
                if ("aeiou".indexOf(palabra.charAt(i)) == -1 && progreso[i] == '_') {
                    progreso[i] = palabra.charAt(i);
                    break;
                }
            }
        }
    }

    // Pone las "_" según cuantas letras haya en la palabra
    public static char[] inicializarProgreso(String palabra) {
        char[] progreso = new char[palabra.length()];
        for (int i = 0; i < progreso.length; i++) {
            progreso[i] = '_';
        }
        return progreso;
    }

    // Comprueba si la letra ya ha sido usada
    public static boolean yaIntentada(char letra, char[] letrasIntentadas) {
        for (char c : letrasIntentadas) {
            if (c == letra) {
                return true;
            }
        }
        return false;
    }

    // Cambia las _ por las letras que acierte
    public static void actualizarProgreso(String palabra, char[] progreso, char letra) {
        for (int i = 0; i < palabra.length(); i++) {
            if (palabra.charAt(i) == letra) {
                progreso[i] = letra;
            }
        }
    }

    // Lo que hace es poner espacios para que no se vea todo junto
    public static void mostrarProgreso(char[] progreso) {
        System.out.println(String.valueOf(progreso).replace("", " ").trim());
    }

    // Dibujo Horca
    public static void mostrarHorca(int intentos) {
        switch (intentos) {
            case 0:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |         \n"
                        + " |         \n"
                        + " |         \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 1:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |         \n"
                        + " |         \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 2:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |       | \n"
                        + " |         \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 3:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |      /| \n"
                        + " |         \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 4:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |      /|\\ \n"
                        + " |         \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 5:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |      /|\\ \n"
                        + " |      /  \n"
                        + " |         \n"
                        + "_|________ ");
                break;
            case 6:
                System.out.println("  _______ \n"
                        + " |       | \n"
                        + " |       O \n"
                        + " |      /|\\ \n"
                        + " |      / \\ \n"
                        + " |         \n"
                        + "_|________ ");
                break;
        }
    }

    // Comprueba si la palabra ha sido resuelta
    public static boolean palabraCompleta(char[] progreso) {
        for (char c : progreso) {
            if (c == '_') {
                return false;
            }
        }
        return true;
    }

    // Obtener las stop words
    public static String[] obtenerStopWords() {
        return new String[]{
            "y", "de", "la", "que", "el", "en", "los", "con", "una", "por", "para", "a", "las", "al", "del", "como", "su", "le", "lo", "se"
        };
    }
    //Busca si la letra está o no dentro de la palabra 

    public static boolean letraEnPalabra(String palabra, char letra) {
        return palabra.indexOf(letra) >= 0;
    }
}
