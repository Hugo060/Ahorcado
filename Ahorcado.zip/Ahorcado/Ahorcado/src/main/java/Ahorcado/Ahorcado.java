package Ahorcado;

public class Ahorcado {

    public static void main(String[] args) {
        System.out.println("Bienvenido al juego del Ahorcado!");
        System.out.println("Introduce '-1' para rendirte.");

        // Iniciar el juego
        Funciones.iniciarJuego("Quijote_completo.txt");
    }
}
